//
//  AvatarViewControllerCell.swift
//  whoisthere
//
//  Created by Efe Kocabas on 10/07/2017.
//  Copyright © 2017 Efe Kocabas. All rights reserved.
//

import UIKit

class AvatarPickerCell : UICollectionViewCell  {
    
    
    @IBOutlet weak var avatarImageView: UIImageView!
    
}
